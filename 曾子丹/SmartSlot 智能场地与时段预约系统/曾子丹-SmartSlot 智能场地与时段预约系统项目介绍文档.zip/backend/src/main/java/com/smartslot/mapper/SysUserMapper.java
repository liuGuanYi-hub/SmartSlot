package com.smartslot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartslot.entity.SysUser;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysUserMapper extends BaseMapper<SysUser> {
}
